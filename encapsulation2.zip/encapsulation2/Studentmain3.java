package encapsulation2;



public class Studentmain3 {

	public static void main(String[] args) {

		Student3 c1 = new Student3();
			c1.setAge (19);
			c1.setName ("ram");
			c1.setId (04);
			//calling the function
			System.out.println (c1.run ());
		// TODO Auto-generated method stub

	}

}
