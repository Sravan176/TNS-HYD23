package encapsulation2;


public class Studentmain2 {

	public static void main(String[] args) {
		Student2 b1=new Student2();
		b1.setAge(18);
		System.out.println(b1.getAge());
		b1.setName("ram");
		System.out.println(b1.getName());
		
		// TODO Auto-generated method stub

	}

}
