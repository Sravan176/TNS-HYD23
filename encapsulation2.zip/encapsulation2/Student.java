package encapsulation2;

public class Student {
	private String name;
    private int id;
    public int age;


}
