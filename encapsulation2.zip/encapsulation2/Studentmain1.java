package encapsulation2;



public class Studentmain1 {

	public static void main(String[] args) {
		Student a1=new Student();
		a1.age=18;
		System.out.println(a1.age);
		// TODO Auto-generated method stub

	}

}
