package day2;

public class Sample {
	int a=10;
	static int b=23;
	int display() {
		return 12;
	} 
	static void display1() {
		System.out.println(16);
	}

	public static void main(String[] args) {
		Sample a1=new Sample();
		System.out.println(a1.a);
		System.out.println(a1.display());
		a1.display();
		System.out.println(Sample.b);
		Sample.display1();
		// TODO Auto-generated method stub

	}

}
