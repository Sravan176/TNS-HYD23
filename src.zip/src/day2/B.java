package day2;

public class B {
		int c=23;
		public static void main(String[] args) {
			B b1=new B();
			System.out.println(b1.c);
			Sample2 a1=new Sample2();
			System.out.println(a1.a);
			a1.display();
			System.out.println(a1.display());
			System.out.println(Sample2.b);
			Sample2.display1();
			
			// TODO Auto-generated method stub

		}
	}


