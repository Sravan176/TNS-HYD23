package day2;


public class User {

		public void msg( ) {
			System.out.println("hello D");
			}

}
