package day2;

public class Sample2 {
	int a=10;
	static int b=12;
	int display() {
		return 14;
	}
	static void display1() {
		System.out.println(20);
	}
}

