package day2;

public class A {
	int a=10;
	static int b=12;
	public static void main(String[] args) {
		int c=23;
		System.out.println(c);
		A a1=new A();
		System.out.println(a1.a);
		System.out.println(A.b);
		// TODO Auto-generated method stub

	}

}
