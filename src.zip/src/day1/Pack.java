package day1;

public class Pack {
	public void msg() {
		System.out.println("hello a");
	}

}
