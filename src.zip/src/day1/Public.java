package day1;

public class Public {
	public void display()
	{
		System.out.println("sravan");
	}

}
