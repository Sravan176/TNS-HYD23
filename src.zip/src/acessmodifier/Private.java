package acessmodifier;

public class Private {
	private void display() {
		System.out.println("TNS java program");
	}

	public static void main(String[] args) {
		Private a1=new Private();
		a1.display();
		// TODO Auto-generated method stub

	}

}
