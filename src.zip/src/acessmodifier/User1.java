package acessmodifier;
import day1.*;
import day2.*;


public class User1 {
	public static void main(String[] args) {
		Pack a1=new Pack();
		a1.msg();
		User d1=new User();
		d1.msg();
		
		
		
		
	}

	

}
