package acessmodifier;
import day1.*;

public class Protect1  extends Hello {

	public static void main(String[] args) {
		System.out.println("tns sesion");
		
		// TODO Auto-generated method stub

	}

}
