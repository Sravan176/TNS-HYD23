package acessmodifier;

public class Protect {


	public void msg(){
		
		System.out.println("hello a");
		// TODO Auto-generated method stub

	}

}
