package acessmodifier;

public class Default {
	void display() {
		System.out.println("hello");
	}
}
 class Default1 {
	public static void main(String[] args) {
		Default a1= new Default();
		a1.display();
		// TODO Auto-generated method stub

	}

}
