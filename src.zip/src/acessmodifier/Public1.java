package acessmodifier;
import day1.*;

public class Public1 {
	public static void main(String[] args) {
		Public obj = new Public();
		obj.display();
	}

}
